import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { QueueToken, ActiveTab } from '../types';
import { INITIAL_TOKENS, DEPARTMENTS } from '../data/initialData';
import {
  generateQrPayload,
  verifyTokenInStore,
  validateStatusTransition,
  VerificationResult,
} from '../utils/tokenLogic';

interface QueueContextType {
  tokens: QueueToken[];
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  activeCustomerTokenId: string | null;
  setActiveCustomerTokenId: (id: string | null) => void;
  bookToken: (
    customerName: string,
    customerPhone: string,
    department: string,
    serviceCenter: string
  ) => QueueToken;
  updateTokenStatus: (
    tokenNumber: string,
    action: 'mark_arrived' | 'mark_serving' | 'mark_completed' | 'cancel',
    counterId?: string
  ) => { success: boolean; message: string; updatedToken?: QueueToken };
  verifyToken: (input: string) => VerificationResult;
  resetDemoData: () => void;
  deleteToken: (tokenNumber: string) => void;
  selectedTokenForScanner: string | null;
  setSelectedTokenForScanner: (tokenNumber: string | null) => void;
}

const QueueContext = createContext<QueueContextType | undefined>(undefined);

const STORAGE_KEY = 'queueless_queue_tokens_v2';
const ACTIVE_CUSTOMER_KEY = 'queueless_active_customer_token_v2';

export const QueueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tokens, setTokens] = useState<QueueToken[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return INITIAL_TOKENS;
  });

  const [activeCustomerTokenId, setActiveCustomerTokenId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(ACTIVE_CUSTOMER_KEY) || 'tok-a024';
    } catch {
      return 'tok-a024';
    }
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('scanner');
  const [selectedTokenForScanner, setSelectedTokenForScanner] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tokens));
    } catch {
      // Ignore
    }
  }, [tokens]);

  useEffect(() => {
    try {
      if (activeCustomerTokenId) {
        localStorage.setItem(ACTIVE_CUSTOMER_KEY, activeCustomerTokenId);
      } else {
        localStorage.removeItem(ACTIVE_CUSTOMER_KEY);
      }
    } catch {
      // Ignore
    }
  }, [activeCustomerTokenId]);

  // Sync across tabs
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) {
            setTokens(parsed);
          }
        } catch {
          // Ignore
        }
      }
      if (e.key === ACTIVE_CUSTOMER_KEY) {
        setActiveCustomerTokenId(e.newValue);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const formatTime = () => {
    const d = new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  };

  const bookToken = useCallback(
    (
      customerName: string,
      customerPhone: string,
      departmentName: string,
      serviceCenterName: string
    ): QueueToken => {
      const dept = DEPARTMENTS.find((d) => d.name === departmentName) || DEPARTMENTS[0];
      const prefix = dept.codePrefix;

      // Find highest number for this prefix
      const deptTokens = tokens.filter((t) => t.tokenNumber.startsWith(prefix));
      let maxNum = 25;
      deptTokens.forEach((t) => {
        const numPart = parseInt(t.tokenNumber.slice(prefix.length), 10);
        if (!isNaN(numPart) && numPart > maxNum) {
          maxNum = numPart;
        }
      });

      const nextNum = maxNum + 1;
      const formattedNum = `${prefix}${nextNum.toString().padStart(3, '0')}`;
      const newId = `tok-${formattedNum.toLowerCase()}-${Date.now().toString(36)}`;
      const qrPayload = generateQrPayload(formattedNum);

      const newToken: QueueToken = {
        id: newId,
        tokenNumber: formattedNum,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim() || undefined,
        serviceCenter: serviceCenterName,
        department: departmentName,
        bookingTime: formatTime(),
        status: 'waiting',
        qrPayload,
        notes: 'Booked online via QueueLess Instant Portal',
      };

      setTokens((prev) => [newToken, ...prev]);
      setActiveCustomerTokenId(newId);
      return newToken;
    },
    [tokens]
  );

  const updateTokenStatus = useCallback(
    (
      tokenNumber: string,
      action: 'mark_arrived' | 'mark_serving' | 'mark_completed' | 'cancel',
      counterId?: string
    ) => {
      const normalized = tokenNumber.trim().toUpperCase();
      const existing = tokens.find((t) => t.tokenNumber.toUpperCase() === normalized);

      if (!existing) {
        return { success: false, message: `Token ${tokenNumber} does not exist.` };
      }

      const check = validateStatusTransition(existing.status, action);
      if (!check.allowed || !check.newStatus) {
        return { success: false, message: check.reason || 'Invalid status transition requested.' };
      }

      const timestamp = formatTime();

      let updatedToken: QueueToken | undefined;
      setTokens((prev) =>
        prev.map((t) => {
          if (t.tokenNumber.toUpperCase() !== normalized) return t;
          const updated: QueueToken = {
            ...t,
            status: check.newStatus!,
          };

          if (check.newStatus === 'arrived') {
            updated.arrivedAt = timestamp;
          } else if (check.newStatus === 'serving') {
            updated.servingAt = timestamp;
            if (counterId) updated.counterId = counterId;
          } else if (check.newStatus === 'completed') {
            updated.completedAt = timestamp;
          }

          updatedToken = updated;
          return updated;
        })
      );

      return {
        success: true,
        message: `Token ${normalized} status successfully updated to "${check.newStatus}".`,
        updatedToken,
      };
    },
    [tokens]
  );

  const verifyToken = useCallback(
    (input: string): VerificationResult => {
      return verifyTokenInStore(tokens, input);
    },
    [tokens]
  );

  const resetDemoData = useCallback(() => {
    setTokens(INITIAL_TOKENS);
    setActiveCustomerTokenId('tok-a024');
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_TOKENS));
    localStorage.setItem(ACTIVE_CUSTOMER_KEY, 'tok-a024');
  }, []);

  const deleteToken = useCallback((tokenNumber: string) => {
    const normalized = tokenNumber.trim().toUpperCase();
    setTokens((prev) => prev.filter((t) => t.tokenNumber.toUpperCase() !== normalized));
  }, []);

  return (
    <QueueContext.Provider
      value={{
        tokens,
        activeTab,
        setActiveTab,
        activeCustomerTokenId,
        setActiveCustomerTokenId,
        bookToken,
        updateTokenStatus,
        verifyToken,
        resetDemoData,
        deleteToken,
        selectedTokenForScanner,
        setSelectedTokenForScanner,
      }}
    >
      {children}
    </QueueContext.Provider>
  );
};

export const useQueue = () => {
  const context = useContext(QueueContext);
  if (!context) {
    throw new Error('useQueue must be used within a QueueProvider');
  }
  return context;
};
